﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assignment_2.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Facultys",
                columns: table => new
                {
                    fid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    fname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    deptid = table.Column<int>(type: "int", nullable: false),
                    standing = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Facultys", x => x.fid);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    sid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    sname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    major = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    standing = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.sid);
                });

            migrationBuilder.CreateTable(
                name: "Classs",
                columns: table => new
                {
                    cid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    room_number = table.Column<int>(type: "int", nullable: false),
                    Facultyfid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Classs", x => x.cid);
                    table.ForeignKey(
                        name: "FK_Classs_Facultys_Facultyfid",
                        column: x => x.Facultyfid,
                        principalTable: "Facultys",
                        principalColumn: "fid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Enrolleds",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Facultyfid = table.Column<int>(type: "int", nullable: false),
                    Studentsid = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enrolleds", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Enrolleds_Facultys_Facultyfid",
                        column: x => x.Facultyfid,
                        principalTable: "Facultys",
                        principalColumn: "fid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Enrolleds_Students_Studentsid",
                        column: x => x.Studentsid,
                        principalTable: "Students",
                        principalColumn: "sid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Classs_Facultyfid",
                table: "Classs",
                column: "Facultyfid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrolleds_Facultyfid",
                table: "Enrolleds",
                column: "Facultyfid");

            migrationBuilder.CreateIndex(
                name: "IX_Enrolleds_Studentsid",
                table: "Enrolleds",
                column: "Studentsid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Classs");

            migrationBuilder.DropTable(
                name: "Enrolleds");

            migrationBuilder.DropTable(
                name: "Facultys");

            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
